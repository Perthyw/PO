# ผลตรวจ PO Desk — 25 กันยายน 2026

## อัตโนมัติ

- `npm test`: 17/17 ผ่าน ครอบคลุม numeric rounding, VAT/NON VAT, invalid input, PostgreSQL schema, RLS, anonymous/outsider access, self-promotion, direct write denial, lifecycle, invoice gate, stale version, idempotency และ atomic rollback
- PostgreSQL ทดสอบด้วย PGlite ในหน่วยความจำ แยกฐานใหม่ทุกครั้ง โดย mock auth.uid boundary ไม่ได้เชื่อม Supabase จริง
- REST adapter ทดสอบด้วย mock fetch: login, authorization header, server paging, network failure, UUID เดิมเมื่อ retry และ session expiry
- `npm run check`: app.js, api.js, domain.js syntax ผ่าน ไม่มี build step (static ES modules)
- ติดตั้ง dependency ทดสอบผ่าน npm: audit รายงาน 0 vulnerabilities ณ เวลาติดตั้ง
- Premium UI strict audit: 0 errors, 0 warnings เก็บผลใน premium-audit.json; เป็น static audit เท่านั้น และตัว auditor ไม่ตรวจ runtime ของ dist ครบทุกกรณี

## Browser จริง (ข้อมูลตัวอย่างเท่านั้น)

- เปิดเว็บแยกที่ localhost:4180; เว็บเดิม 4173 ไม่ถูกแก้/ใช้ทดสอบ
- สร้างรายการ VAT จำนวน 2 × 100 บาท ก่อน VAT, 107 บาทหลัง VAT → ฐาน 200 / ภาษี 14 / รวม 214 บาท ในหน้าตรวจทาน
- กรอกไม่ครบถูกปฏิเสธ มีข้อความและ focus ช่องชื่อสินค้า
- เปิด PO แล้วกลับรายการ แสดงเลข DEMO ใหม่และข้อความสำเร็จ
- ออฟฟิศไม่มีปุ่มอนุมัติ; สลับ demo เจ้าของแล้วอนุมัติ → รอรับสินค้า
- ออฟฟิศติ๊กรับสินค้า → รอใบกำกับ; ออฟฟิศไม่มีปุ่มปิด
- เจ้าของกดปิดโดยไม่ติ๊กได้รับใบกำกับไม่ได้; ติ๊กแล้วยืนยัน → ปิด PO พร้อมประวัติ 4 เหตุการณ์
- ปฏิเสธโดยไม่ใส่เหตุผลไม่ได้; ใส่เหตุผลแล้วแสดงเหตุผลและประวัติ
- มือถือ request 390×844 (host layout viewport 355px): page scrollWidth 345px ไม่ล้น; ตารางมี internal width 278px / scrollWidth 650px; ฟอร์ม width ไม่ล้น
- ร่างที่ยังไม่ส่งมี dialog เตือนออก; Escape ปิด dialog คืน focus ให้ปุ่มเดิมและข้อมูลยังอยู่
- Global scrollbar computed color ตรง tokens; ทดสอบ dialog ในจอแคบได้
- WebMCP read_visible_purchase_orders เรียก valid input ได้ข้อมูล 5 ใบ; unexpected input ถูกปฏิเสธ
- Browser console ที่ตรวจไม่พบ error/warn; คืน viewport เดิมแล้ว

## ข้อจำกัดและสถานะเผยแพร่

- ยังไม่มี Supabase project จริง: ยังไม่ได้พิสูจน์ live Auth/REST, refresh token, multi-device หรือ network failure ในบริการจริง ต้องทำ checklist SUPABASE-SETUP.md ก่อนใช้งานจริง
- โหมดตัวอย่างไม่บันทึกถาวร รีโหลดเริ่มใหม่; หลังตั้งค่า Supabase จะเปิดหน้าล็อกอินและไม่ fallback กลับ demo เมื่อ API ล้มเหลว
- ไม่มีการทดสอบอุปกรณ์มือถือจริง, screen reader, production load, offline/slow UI simulation หรือ full 200% zoom matrix
- ไม่มีตัวเลือก dropdown/date picker: วันที่/เวลามาจาก server ไม่ใช่ฟอร์มที่ต้องเปิด popup
- Sites จดทะเบียนโปรเจกต์ไว้แล้วตาม .openai/hosting.json แต่ยังไม่ได้ publish: ชุด scripts ของ plugin Sites ไม่ปรากฏบน filesystem ระหว่างขั้นเผยแพร่ (site-workflow.mjs ไม่พบหลังค้น cache) ไม่สร้าง Site ซ้ำและไม่อ้างว่ามี live URL
- ส่งมอบแพ็กเกจ static po-desk-web.zip และซอร์ส po-desk-source.zip สำหรับนำขึ้นโฮสต์เองตาม DEPLOY.md

ไม่แก้ source, server หรือฐานข้อมูล Grandhouse เดิม
