---
version: beta
name: PO Desk
description: Thai purchase-order tracking workspace inspired by the clarity of parcel tracking.
colors:
  primary: '#164b49'
  primaryHover: '#0c3635'
  background: '#f3f6f6'
  panel: '#ffffff'
  text: '#172e32'
  muted: '#5a6c70'
  border: '#dce5e5'
  accent: '#e8b85b'
  success: '#21624b'
  danger: '#a42c42'
typography:
  sans:
    fontFamily: 'Tahoma, Leelawadee UI, sans-serif'
  mono:
    fontFamily: 'Consolas, monospace'
rounded:
  DEFAULT: '14px'
  control: '9px'
spacing:
  section-gap: '22px'
  page-max: '1320px'
components:
  button: {}
  field: {}
  tracker: {}
  dialog: {}
---

# PO Desk Design System

## Overview

North Star: a purchase document with the immediate readability of parcel tracking. Thai office staff request; owner decides; both follow the same four-circle route. Product/admin register, Thai-language work on desktop and phone per the user's brief. No Japanese market scope. New independent identity, not an extension of Grandhouse.

Signature: a compact, repeated four-stop tracking line with an explicit stage label on every PO. Deep teal spine, white document panels, restrained amber for waiting. No hero, stock photography, decorative charts, or fabricated business data outside labelled demo mode.

Runtime token owner: `dist/style.css :root` (Model B). This document mirrors primary→--brand, primaryHover→--brand-hover, background→--paper, panel→--panel, text→--ink, muted→--muted, border→--line, accent→--accent, success→--success, danger→--danger. Shared helpers in app.js consume CSS classes.

## Colors

Teal for primary actions, amber waiting, blue receipt pending, plum invoice pending, green closed, red rejection. Every status has text; no color-only state. White/light surfaces only. Focus is amber with outline; forced colors uses system values.

## Typography

Local Thai-capable Tahoma/Leelawadee UI, 15px base and 1.65 line height. Headings 25–30px. PO identifiers use Consolas; monetary values tabular. No remote font dependency or swap. Thai dates use Buddhist calendar and Asia/Bangkok; ISO timestamps in storage.

## Layout

238px desktop navigation, max content 1320px, 42px content inset. At 1100px reduce navigation/inset and stack each order tracker; at 700px compact horizontal navigation and two-column summary tiles, one-column forms. Document owns vertical scrolling; tables own horizontal overflow. Mobile inset 16px. Forms grow naturally.

## Elevation & Depth

Use borders for panels. Only modal overlays have a substantial shadow. Avoid nested shadow cards.

## Shapes

Panels 14px, order documents 11px, controls 9px. Circles reserved for progress and identity; badges use compact corners.

## Components

Shared field(), tracker(), badge(), itemsTable(), summary(), openModal(), notify() and withPending() in dist/app.js. Native labelled inputs and checkbox; native dialog provides focus containment, Escape and inert background. No select/date picker required: date/time are server-generated. Buttons distinguish primary, neutral, danger; hover, focus, active, disabled and aria-busy provided. Native dialog starts on cancel for consequential action. Loading uses fixed minimum space and meaningful text. Errors preserve form values, associate field feedback and focus first invalid input. One global live status. Common action labels imported from domain.js.

Icons are supplementary text symbols, never the sole action name. Motion is minimal, reduced-motion respected. Thai labels and THB two-decimal figures. Status tracker always has text equivalent.

## Do's and Don'ts

- Do show demo mode and lack of durable storage explicitly.
- Do keep amount, status, and next action easy to scan.
- Don't infer a VAT rate or skip invoice confirmation for NON VAT.
- Don't use browser role selection as production authorization.
