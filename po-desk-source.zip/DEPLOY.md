# ขึ้นเว็บ PO Desk

`dist/` เป็นเว็บ static พร้อมใช้กับโฮสต์ HTTPS ที่รองรับไฟล์ HTML/CSS/JavaScript เช่น Cloudflare Pages, Netlify หรือ static hosting ทั่วไป ไม่มี server secret ในเว็บ

1. เชื่อม Supabase ตาม SUPABASE-SETUP.md และทดสอบก่อนใช้จริง
2. อัปโหลดไฟล์ทั้งหมด **ภายใน dist/** เป็น root ของเว็บไซต์ ไม่อัปโหลด test/, node_modules/ หรือไฟล์ฐานข้อมูล
3. ไม่ต้องรัน build command; publish directory คือ `dist`
4. ใช้ HTTPS สำหรับเว็บจริง ตรวจว่าเส้นทาง `app.js`, `api.js`, `domain.js`, `config.js`, `style.css`, `favicon.svg` โหลดได้ และตั้ง JavaScript MIME type ให้ถูกต้อง
5. อัปเดตไฟล์ config แล้วต้อง deploy ใหม่ ค่า URL/key เป็น public configuration ไม่ใช่ service-role key

การทดลองผ่าน Sites ใช้สิทธิ์ private ของเจ้าของ Site; ยังไม่ใช่ช่องทางสำหรับให้พนักงานภายนอกเข้าใช้ หากจะใช้ Sites กับทีมต้องตั้งสิทธิ์เข้าถึงให้เหมาะสม หรือย้าย dist ไปโฮสต์ขององค์กร

ไม่มีข้อมูลในเว็บที่ต้องย้ายเมื่อเปลี่ยนโฮสต์ ข้อมูลจริงอยู่ใน Supabase ของเว็บ PO เท่านั้น โหมดตัวอย่างไม่มีการบันทึกถาวร
