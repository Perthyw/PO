# PO Desk UX contract

Business authority: PRODUCT.md (2026-09-25 explicit user request). Supabase setup and storage contracts: SUPABASE-SETUP.md and supabase/001_schema.sql. New independent app, no sibling legacy workflow to inherit.

## Canonical UI Map

| Capability | Canonical owner | Source of truth | Allowed variants | Verification |
|---|---|---|---|---|
| Form | field(), errorField(), validateItems() | PRODUCT.md | create/review/login/reason | domain tests + browser |
| Scrollbar | dist/style.css global baseline | DESIGN.md | page/table/modal | narrow browser inspection |
| Toast | notify() and #toast live region | this contract | success only after committed result | browser |
| CRUD | api.js, create_po(), act_on_po() | PRODUCT.md | create/read/transition; no edit/delete | database tests |
| Dialog | openModal() native dialog | this contract | confirm/reason/discard | focus/Escape/browser |
| Date | PostgreSQL now(), domain.date() | PRODUCT.md | display only; no picker | database + browser |

Select/Listbox and Table Selection are not applicable (no dropdown or bulk selection).

## Flow ledger

- Open PO → validate → review → submit → list and success status. Back to edit keeps values. Source PRODUCT.md.
- Approve/reject/receive/close → object-specific dialog → pending disabled buttons → authoritative RPC → refreshed detail and success status. Source PRODUCT.md.
- Reject requires reason; receive and close require explicit checkbox; close only after receipt. Owner alone closes. Source PRODUCT.md.
- Failure keeps review/dialog and values with inline error/retry. Timeout retry uses same UUID. Changed version requires refresh. No silent retry under a new identity.
- Create key changes when draft changes; repeat submit of identical draft is idempotent. Action keys are stable while dialog stays open.
- Tables/PO list use server pagination of 10. Status/page persist in query parameters; reset page on filter changes. API has explicit count; no partial client filtering.
- Drafts stay in memory. Warn on in-app navigation and beforeunload. Reauthentication preserves draft only for same account. No browser persistent storage for session or PO records.
- Demo uses separate memory only, visible banner and DEMO identifiers; production cannot switch roles in UI and never falls back to demo on failure.
- All active team members see all team PO records. No hard delete or user management UI.

## Locale, accessibility and recovery

Thai labels, Thai dates and Bangkok timezone, two-decimal THB. Native operating-system text/number/checkbox inputs; no authored picker. Semantic buttons and tables. Visible keyboard focus. Modal focus trap/inert background via HTML dialog; restore focus when opener survives. Screen-reader text on completed progress steps. Error feedback role alert, success role status. Global scrollbar visible; no whole-page horizontal overflow. No speculative legal copy, notifications or payments.

## Verification

test/database.test.mjs tests real PostgreSQL behavior in isolated PGlite with a mocked Supabase auth.uid/session boundary. This is not a real Supabase integration test. test/domain.test.mjs tests money and state rules. VERIFICATION.md records exact checks and browser coverage; missing external integration remains explicit.
