# PO Desk business contract

Source: explicit user request dated 2026-09-25, confirmed no Supabase project exists; prepare integration first.

Independent app, code, database, accounts, and deployment. No Grandhouse integration.
One office team requests POs. Owner approves or rejects (rejection requires reason). Office confirms goods received. Only owner can close after physically receiving/checking the invoice. NON VAT does not bypass document confirmation. No payment, vendor dispatch, inventory, HR, multi-company, attachments, or delete feature requested.

PO items: product name, specification, positive quantity, net unit price, VAT flag, explicitly entered VAT-inclusive unit price if VAT. Review before immutable submission. Dates/times generated on submit. Monetary values use half-up per-line rounding to satang, then sums of lines; no inferred tax rate. UI and database share these rules. Whole-PO receipt confirmation; no partial receipt was requested.

All provisioned office/owner accounts belong to this single team and can read team PO records. Account provisioning is administrator-only, not self-signup. RPCs are sole mutation boundary. Event history is append-only to app users. No deletion/retention automation, external side effects, payments, or legal claims.
