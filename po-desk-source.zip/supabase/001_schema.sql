-- Apply once to a NEW Supabase project dedicated to PO Desk.
begin;
create table public.profiles (
 id uuid primary key references auth.users(id),
 display_name text not null check (length(btrim(display_name)) between 1 and 200),
 role text not null check (role in ('office','owner'))
);
create sequence public.po_number_seq;
create table public.purchase_orders (
 id uuid primary key default gen_random_uuid(),
 po_number text not null unique,
 created_at timestamptz not null default now(),
 created_by uuid not null references public.profiles(id),
 requester_name text not null,
 status text not null default 'pending' check (status in ('pending','approved','received','closed','rejected')),
 items jsonb not null check (jsonb_typeof(items)='array' and jsonb_array_length(items) between 1 and 50),
 base_cents bigint not null check(base_cents>0),
 tax_cents bigint not null check(tax_cents>=0),
 total_cents bigint not null check(total_cents=base_cents+tax_cents),
 version integer not null default 1,
 rejection_reason text,
 invoice_confirmed boolean not null default false,
 check(status<>'closed' or invoice_confirmed),
 check(status<>'rejected' or length(btrim(rejection_reason))>0)
);
create index po_status_created on public.purchase_orders(status,created_at desc);
create index po_created on public.purchase_orders(created_at desc);
create table public.po_events (
 id uuid primary key default gen_random_uuid(),
 po_id uuid not null references public.purchase_orders(id),
 actor_id uuid not null references public.profiles(id),
 actor_name text not null,
 action text not null check(action in ('create','approve','reject','receive','close')),
 at timestamptz not null default now(),
 reason text not null default ''
);
create index po_events_order on public.po_events(po_id,at);
create table public.po_commands (
 actor_id uuid not null references public.profiles(id),
 request_id uuid not null,
 payload jsonb not null,
 result jsonb not null,
 primary key(actor_id,request_id)
);
alter table public.profiles enable row level security;
alter table public.purchase_orders enable row level security;
alter table public.po_events enable row level security;
alter table public.po_commands enable row level security;
revoke all on public.profiles,public.purchase_orders,public.po_events,public.po_commands from anon,authenticated;
revoke all on sequence public.po_number_seq from anon,authenticated;
grant select on public.profiles,public.purchase_orders,public.po_events to authenticated;
create policy profile_self on public.profiles for select to authenticated using(id=(select auth.uid()));
create policy po_team_read on public.purchase_orders for select to authenticated using(exists(select 1 from public.profiles where id=(select auth.uid())));
create policy events_team_read on public.po_events for select to authenticated using(exists(select 1 from public.profiles where id=(select auth.uid())));

create function public.create_po(p_items jsonb,p_request_id uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare
 a public.profiles%rowtype; p public.purchase_orders%rowtype; c public.po_commands%rowtype;
 i jsonb; normalized jsonb='[]'; payload jsonb; q numeric; price numeric; gross numeric;
 base bigint; total bigint; sum_base bigint=0; sum_total bigint=0; vat boolean; item_name text; spec text;
begin
 select * into a from public.profiles where id=auth.uid();
 if a.id is null or a.role<>'office' then raise exception 'เฉพาะออฟฟิศที่ได้รับสิทธิ์เท่านั้นที่เปิด PO ได้'; end if;
 if p_request_id is null then raise exception 'ไม่พบหมายเลขคำขอ'; end if;
 payload=jsonb_build_object('action','create','items',p_items);
 perform pg_advisory_xact_lock(hashtextextended(a.id::text||p_request_id::text,0));
 select * into c from public.po_commands where actor_id=a.id and request_id=p_request_id;
 if found then
  if c.payload<>payload then raise exception 'หมายเลขคำขอนี้ใช้กับข้อมูลอื่นแล้ว'; end if;
  return c.result;
 end if;
 if p_items is null or jsonb_typeof(p_items)<>'array' then raise exception 'ระบุรายการสินค้า'; end if;
 if jsonb_array_length(p_items) not between 1 and 50 then raise exception 'ระบุสินค้า 1–50 รายการ'; end if;
 for i in select value from jsonb_array_elements(p_items) loop
  item_name=btrim(coalesce(i->>'name','')); spec=btrim(coalesce(i->>'spec',''));
  if length(item_name) not between 1 and 200 or length(spec) not between 1 and 2000 then raise exception 'ระบุชื่อสินค้าและสเปคให้ครบ'; end if;
  if coalesce(i->>'qty','') !~ '^[0-9]{1,9}(\.[0-9]{1,3})?$' or coalesce(i->>'unit_price','') !~ '^[0-9]{1,9}(\.[0-9]{1,2})?$' then raise exception 'จำนวนหรือราคาไม่ถูกต้อง'; end if;
  if jsonb_typeof(i->'vat') is distinct from 'boolean' then raise exception 'ระบุ VAT หรือ NON VAT'; end if;
  q=(i->>'qty')::numeric;price=(i->>'unit_price')::numeric;vat=(i->>'vat')::boolean;
  if vat then
   if coalesce(i->>'gross_unit','') !~ '^[0-9]{1,9}(\.[0-9]{1,2})?$' then raise exception 'ระบุราคาหลัง VAT'; end if;
   gross=(i->>'gross_unit')::numeric;
  else gross=price;
  end if;
  if q<=0 or q>1000000 or price<=0 or price>1000000000 or gross<price or gross>1000000000 then raise exception 'จำนวนหรือราคาอยู่นอกช่วงที่รองรับ'; end if;
  base=round(q*price*100);total=round(q*gross*100);
  if total>100000000000 or base<=0 then raise exception 'ยอดต่อรายการต้องอยู่ระหว่าง 0.01 ถึง 1,000,000,000 บาท'; end if;
  normalized=normalized||jsonb_build_array(jsonb_build_object('name',item_name,'spec',spec,'qty',q::text,'unit_price',price::text,'vat',vat,'gross_unit',gross::text,'base_cents',base,'tax_cents',total-base,'total_cents',total));
  sum_base=sum_base+base;sum_total=sum_total+total;
 end loop;
 insert into public.purchase_orders(po_number,created_by,requester_name,items,base_cents,tax_cents,total_cents)
 values('PO-'||to_char(now() at time zone 'Asia/Bangkok','YYYY')||'-'||lpad(nextval('public.po_number_seq')::text,6,'0'),a.id,a.display_name,normalized,sum_base,sum_total-sum_base,sum_total) returning * into p;
 insert into public.po_events(po_id,actor_id,actor_name,action) values(p.id,a.id,a.display_name,'create');
 insert into public.po_commands values(a.id,p_request_id,payload,to_jsonb(p));
 return to_jsonb(p);
end $$;

create function public.act_on_po(p_id uuid,p_action text,p_version integer,p_reason text,p_invoice_confirmed boolean,p_request_id uuid) returns jsonb
language plpgsql security definer set search_path='' as $$
declare a public.profiles%rowtype;p public.purchase_orders%rowtype;c public.po_commands%rowtype;payload jsonb;next_status text;reason text=btrim(coalesce(p_reason,''));
begin
 select * into a from public.profiles where id=auth.uid();
 if a.id is null then raise exception 'บัญชีนี้ไม่มีสิทธิ์ใช้งาน'; end if;
 if p_request_id is null or p_version is null then raise exception 'คำขอไม่ครบถ้วน'; end if;
 if p_action is null or p_action not in ('approve','reject','receive','close') then raise exception 'คำสั่งไม่ถูกต้อง'; end if;
 if (p_action='receive' and a.role<>'office') or (p_action in ('approve','reject','close') and a.role<>'owner') then raise exception 'บทบาทนี้ไม่มีสิทธิ์ทำรายการ'; end if;
 payload=jsonb_build_object('id',p_id,'action',p_action,'version',p_version,'reason',reason,'invoice',p_invoice_confirmed);
 perform pg_advisory_xact_lock(hashtextextended(a.id::text||p_request_id::text,0));
 select * into c from public.po_commands where actor_id=a.id and request_id=p_request_id;
 if found then
  if c.payload<>payload then raise exception 'หมายเลขคำขอนี้ใช้กับข้อมูลอื่นแล้ว'; end if;
  return c.result;
 end if;
 select * into p from public.purchase_orders where id=p_id for update;
 if not found then raise exception 'ไม่พบใบ PO'; end if;
 if p.version<>p_version then raise exception 'สถานะเปลี่ยนแล้ว กรุณากลับรายการและโหลดข้อมูลล่าสุด'; end if;
 if length(reason)>2000 then raise exception 'เหตุผลต้องไม่เกิน 2,000 ตัวอักษร'; end if;
 if p_action in ('approve','reject') and p.status='pending' then
  if p_action='reject' and reason='' then raise exception 'ระบุเหตุผลที่ไม่อนุมัติ'; end if;
  next_status=case when p_action='approve' then 'approved' else 'rejected' end;
 elsif p_action='receive' and p.status='approved' then next_status='received';
 elsif p_action='close' and p.status='received' then
  if p_invoice_confirmed is distinct from true then raise exception 'ต้องยืนยันว่าได้รับใบกำกับภาษีแล้ว'; end if;
  next_status='closed';
 else raise exception 'ไม่สามารถดำเนินการในสถานะนี้ได้';
 end if;
 update public.purchase_orders set status=next_status,version=version+1,
 rejection_reason=case when p_action='reject' then reason else rejection_reason end,
 invoice_confirmed=case when p_action='close' then true else invoice_confirmed end
 where id=p.id returning * into p;
 insert into public.po_events(po_id,actor_id,actor_name,action,reason) values(p.id,a.id,a.display_name,p_action,reason);
 insert into public.po_commands values(a.id,p_request_id,payload,to_jsonb(p));
 return to_jsonb(p);
end $$;

create function public.po_counts() returns jsonb language sql stable security invoker set search_path='' as $$
 select coalesce(jsonb_object_agg(status,n),'{}'::jsonb) from (select status,count(*) as n from public.purchase_orders group by status) counts;
$$;
revoke all on function public.create_po(jsonb,uuid),public.act_on_po(uuid,text,integer,text,boolean,uuid),public.po_counts() from public,anon;
grant execute on function public.create_po(jsonb,uuid),public.act_on_po(uuid,text,integer,text,boolean,uuid),public.po_counts() to authenticated;
commit;
