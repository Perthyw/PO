# เชื่อม Supabase สำหรับ PO Desk

สถานะปัจจุบัน: ยังไม่มี Supabase project จริง จึงยังไม่ได้ทดสอบ Auth, REST, network หรือ RLS บน Supabase จริง

1. สร้าง project ใหม่สำหรับ PO Desk โดยเฉพาะ ห้ามใช้ project / ตาราง Grandhouse
2. เปิด SQL Editor แล้วรัน `supabase/001_schema.sql` หนึ่งครั้ง สคริปต์เป็น transaction และจงใจไม่ drop / overwrite ตารางเดิม
3. ปิดการสมัครสมาชิกสาธารณะใน Authentication ใช้บัญชีที่ผู้ดูแลสร้างเท่านั้น สร้างผู้ใช้ออฟฟิศและเจ้าของผ่าน Supabase Dashboard และกำหนดรหัสผ่านที่ปลอดภัยโดยผู้ใช้เอง
4. คัดลอก UUID ของผู้ใช้ ใส่โปรไฟล์ด้วย SQL ด้านล่าง (แทนค่าตัวอย่างทั้งสองค่า):

```sql
insert into public.profiles(id, display_name, role)
values ('UUID-OF-OFFICE', 'ออฟฟิศ', 'office'),
       ('UUID-OF-OWNER', 'เจ้าของ', 'owner');
```

5. แก้ `dist/config.js` เป็น Project URL และ publishable key จาก project ใหม่นี้:

```js
export const config = {
  supabaseUrl: 'https://YOUR-PROJECT.supabase.co',
  publishableKey: 'YOUR-PUBLISHABLE-KEY'
};
```

ห้ามใส่ secret key, service-role key หรือรหัสผ่านฐานข้อมูลลงในไฟล์เว็บไซต์ Publishable key มีไว้ให้ browser ใช้ โดย RLS และ RPC จำกัดสิทธิ์อีกชั้น

6. เปิดเว็บแล้วเข้าสู่ระบบ ทดสอบรายการสมมติในโปรเจกต์ทดสอบก่อนเปิดใช้จริง ใช้ checklist ด้านล่าง

## สิทธิ์และข้อมูล

- หนึ่งโปรเจกต์ = หนึ่งทีมออฟฟิศและเจ้าของ สมาชิกที่มี profiles อ่าน PO และประวัติทั้งทีมได้
- ออฟฟิศเปิด PO และยืนยันรับสินค้า เจ้าของอนุมัติ/ปฏิเสธ/ปิด PO
- ผู้ใช้ทั่วไปเพิ่ม profiles หรือแก้ role ตัวเองไม่ได้ ผู้ดูแลโปรเจกต์เป็นผู้กำหนดเท่านั้น
- ผู้ไม่มี profile และ anonymous อ่าน PO ไม่ได้
- ตาราง PO, profiles, events, commands ไม่เปิด direct insert/update/delete ให้ browser การเขียน PO ผ่าน RPC ที่ตรวจ auth.uid และ role เท่านั้น
- ราคาและยอดรวมคำนวณใหม่ด้วย numeric ใน PostgreSQL ไม่เชื่อยอดจาก browser
- เก็บเงินเป็นสตางค์ ปัด half-up ต่อบรรทัด: ฐาน=round(จำนวน×ราคาก่อน VAT,2), รวม=round(จำนวน×ราคาหลัง VAT,2), VAT=รวม−ฐาน
- จำนวนทศนิยมไม่เกิน 3 ตำแหน่ง ราคาทศนิยมไม่เกิน 2 ตำแหน่ง สูงสุด 50 รายการต่อใบ ยอดแต่ละรายการไม่เกิน 1,000,000,000 บาท
- ใช้ request UUID ป้องกันส่งซ้ำ, lock แถวและ version ป้องกันการอนุมัติจากข้อมูลเก่า
- ประวัติเก็บผู้ดำเนินการ เวลา เหตุผล และชื่อ ณ เวลาทำรายการ ไม่เปิดลบ/แก้จากเว็บ
- เวลาเซิร์ฟเวอร์ UTC แสดงเวลาไทย Asia/Bangkok และปี พ.ศ.
- Session token อยู่ในหน่วยความจำ browser เท่านั้น รีโหลดต้องเข้าสู่ระบบใหม่ ต่ออายุ token ระหว่างใช้งาน ร่างอยู่ในหน่วยความจำและเตือนก่อนออก
- ถ้าเชื่อมต่อ Supabase ไม่ได้จะแจ้งข้อผิดพลาด ไม่สลับกลับใช้ demo เงียบ ๆ

## ตรวจจริงก่อนใช้งาน

- บัญชี office เปิด PO พร้อม VAT/NON VAT และยอดตรงหน้าตรวจทาน
- บัญชี owner เปิด PO ไม่ได้ บัญชี office อนุมัติ/ปิดไม่ได้ รวมถึงเรียก RPC โดยตรง
- ผู้ไม่มี profile และ anonymous อ่านข้อมูลไม่ได้
- ปฏิเสธโดยไม่มีเหตุผลไม่ได้ รับก่อนอนุมัติไม่ได้ ปิดก่อนรับหรือก่อนยืนยันใบกำกับไม่ได้
- เรียกคำขอเดิมซ้ำไม่เพิ่ม PO หรือ audit ซ้ำ สองหน้าจอทำงานใบเดียวกันต้องพบ conflict
- ทดลองหมดอายุ session, network timeout, retry และตรวจรายการจริงหลังข้อผิดพลาด
- ตรวจ Supabase Security Advisor และการสำรองข้อมูลตามแผนใช้งานของโปรเจกต์

อ้างอิง: [Supabase RLS](https://supabase.com/docs/guides/database/postgres/row-level-security), [Database functions](https://supabase.com/docs/guides/database/functions), [Password Auth](https://supabase.com/docs/guides/auth/passwords)
